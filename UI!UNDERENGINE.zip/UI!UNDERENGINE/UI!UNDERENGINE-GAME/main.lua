function love.load()
    heart = love.graphics.newImage("SPRITES/SOUL.png")
    button_atk = love.graphics.newImage("SPRITES/BUTTONS/ATK-0.png")
    button_act = love.graphics.newImage("SPRITES/BUTTONS/ACT-0.png")
    button_obj = love.graphics.newImage("SPRITES/BUTTONS/OBJ-0.png")
    button_pce = love.graphics.newImage("SPRITES/BUTTONS/PCE-0.png")
    enemy = love.graphics.newImage("SPRITES/ENEMY.png")
    soul = {}
    soul.x = 395
    soul.y = 350
    soul.speed = 150
    atk = {}
    atk.x = 50
    atk.y = 500
    act = {}
    act.x = 250
    act.y = 500
    obj = {}
    obj.x = 450
    obj.y = 500
    pce = {}
    pce.x = 650
    pce.y = 500
    rival = {}
    rival.x = 320
    rival.y = 20
    source = love.audio.newSource("MUSIC/FIRE AND FLAMES.mp3", "stream")
end

function love.update(dt)
    if love.keyboard.isDown("right") then
	soul.x = soul.x + (soul.speed * dt)
    end

    if love.keyboard.isDown("left") then
	soul.x = soul.x - (soul.speed * dt)
    end

    if love.keyboard.isDown("up") then
	soul.y = soul.y - (soul.speed * dt)
    end

    if love.keyboard.isDown("down") then
	soul.y = soul.y + (soul.speed * dt)
    end

    if not source:isPlaying() then
		love.audio.play(source)
	end
end

function love.draw()
    love.graphics.draw(button_atk, atk.x, atk.y)
    love.graphics.draw(button_act, act.x, act.y)
    love.graphics.draw(button_obj, obj.x, obj.y)
    love.graphics.draw(button_pce, pce.x, pce.y)
    love.graphics.draw(enemy, rival.x, rival.y)
    love.graphics.draw(heart, soul.x, soul.y)
end